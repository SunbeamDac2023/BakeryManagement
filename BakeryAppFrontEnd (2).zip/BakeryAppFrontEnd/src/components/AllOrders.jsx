import React from 'react'

const AllOrders = () => {
  return (
   <div>hi</div>

  )
}

export default AllOrders;