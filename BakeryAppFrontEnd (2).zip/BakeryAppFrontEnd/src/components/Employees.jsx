import React from 'react'
import { useState, useEffect } from 'react';

const Employees = () => {

    const [employees, setEmployees] = useState([]);
    const [employee, setEmployee] =
        useState({ id: 0, empName: "", empEmail: "" });

    //Onload display purpose.
    useEffect(() => {
        getAllEmployees();
    }, []);

    //Any changes happens to these two states, component will render again. 
    useEffect(() => {
        console.log("Component Did Update is called..")
    }, [employees, employee]);

    //Get all employees list (select query);
    const getAllEmployees = () => {
        debugger;
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = () => {
            debugger;
            if (helper.readyState == 4 &&
                helper.status == 200) {
                debugger;
                var result =
                    JSON.parse(helper.responseText);

                setEmployees(result);
                debugger;
                console.log(Employees.length);




                console.log("Setting Emps to Array received from reqres.in website..")
                debugger;

            }
        };
        helper.open("GET", "http://localhost:8080/vendor/employees");
        helper.send();

    }

    return (
        <>

            <section
                className="grid grid-cols-1 md:grid-cols-2 gap-2 w-full "
                id="aboutUs"
            >
                <div className="py-2 flex-1 flex flex-col items-start justify-center gap-6">
                    <div className="flex items-center gap-2 justify-center bg-orange-100 px-4 py-1 rounded-full">
                        <p className="text-[1.5rem] lg:text-[1.5rem] text-orange-500 font-semibold">
                            <h1 >Admin Dashboard !</h1>
                        </p>

                    </div>
                </div>
            </section>
            <br />
            <hr></hr>
            <br />
            <div className="flex flex-col ">
                <div className="overflow-x-auto sm:-mx-6 lg:-mx-8 drop-shadow-lg">
                    <div className="inline-block min-w-full py-2 sm:px-6 lg:px-8 ">
                        <div className="overflow-hidden rounded-lg">
                            <table className="min-w-full text-center text-sm font-light " >
                                <thead className="border-b bg-neutral-800 font-medium text-lg text-white dark:border-neutral-500 dark:bg-neutral-700">
                                    <tr>
                                        <th scope="col" className=" px-6 py-4">
                                            Id
                                        </th>
                                        <th scope="col" className=" px-6 py-4">
                                            Employee Name
                                        </th>
                                        <th scope="col" className=" px-6 py-4">
                                            Employee Email
                                        </th>
                                        {/* <th scope="col" className=" px-6 py-4">
                                            Action
                                        </th> */}
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        employees.map((employee) => {
                                            return (
                                                <tr id={employee.id} className="border-b dark:border-neutral-500">
                                                    <td className="whitespace-nowrap  px-6 py-4 font-semibold">{employee.id}</td>
                                                    <td className="whitespace-nowrap  px-6 py-4">{employee.empName}</td>
                                                    <td className="whitespace-nowrap  px-6 py-4">{employee.empEmail}</td>

                                                </tr>
                                            )
                                        }



                                        )


                                    }


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <br />
            <hr></hr>
            <br />

        </>
    )
}

export default Employees;