import React from 'react'

function AdminDashboardRow(props) {
  return (
   
   <div>
    
   </div>
  )
}

export default AdminDashboardRow