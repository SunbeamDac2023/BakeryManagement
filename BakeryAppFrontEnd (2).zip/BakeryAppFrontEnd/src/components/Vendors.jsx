import { useEffect, useState } from 'react';

const Vendors = () => {


    const [vendors, setVendors] = useState([]);
    const [vendor, setVendor] =
        useState({ id: 0, vendorName: "", vendorEmail: "", vendorAddress: "", vendorPassword: "" });




    useEffect(() => {
        console.log("Component Did Update is called..")
    }, [vendors, vendor]);


    useEffect(() => {
        getAllVendors();
    }, []);

   //Adding new vendor
    const addVendor = () => {
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = () => {
            if (helper.readyState == 4 &&
                helper.status == 200) {
                var responseReceived =
                    JSON.parse(helper.responseText);



                getAllVendors();
                setVendor({ vendorName: "", vendorEmail: "", vendorAddress: "", vendorPassword: "" });


            }
        };
        helper.open("POST", "http://localhost:8080/admin/addvendor");
        helper.setRequestHeader("Content-Type", "application/json")
        helper.send(JSON.stringify(vendor));

    }

    //Get all vendor list (select query)
    const getAllVendors = () => {
        debugger;
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = () => {
            debugger;
            if (helper.readyState == 4 &&
                helper.status == 200) {
                debugger;
                var result =
                    JSON.parse(helper.responseText);
                //   var receivedVendors = result;
                setVendors(result);
                debugger;
                console.log(vendors.length);




                console.log("Setting Emps to Array received from reqres.in website..")
                debugger;

            }
        };
        helper.open("GET", "http://localhost:8080/admin/vendors");
        helper.send();

    }
    //deleting the vendor
    const deleteVendor=(id)=>
    {
        debugger;
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = ()=>{
            if(helper.readyState == 4 &&
                helper.status == 200)
                {
                    var responseReceived = 
                        JSON.parse(helper.responseText);
                   
                 
                    
                       getAllVendors();
                  
                   
                }
        };
        helper.open("DELETE", 
                        "http://localhost:8080/admin/delete/"+id);
        helper.send();   
    }

    const editVendor=(id)=>{
        debugger;
        console.log("You need to find record with id = " + id + " from - ");

        console.log(vendors)

        vendors.map((vendorToEdit)=>{
            if(vendorToEdit.id === id)
            {
                
                var copyOfVendorToEditFromArray  =
                   {...vendorToEdit} 
                copyOfVendorToEditFromArray.vendorPassword = "**********"
                setVendor(copyOfVendorToEditFromArray);
                return;
            }
        })
    }

   //for updating the record 
    const updateVendor=()=>{
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = ()=>{
            if(helper.readyState == 4 &&
                helper.status == 200)
                {
                    var responseReceived = 
                        JSON.parse(helper.responseText);
                  
                  
                      
                        getAllVendors();
                        setVendor({ id:0 ,vendorName: "", vendorEmail: "", vendorAddress: "", vendorPassword: "" });
               
                    
                }
        };
        helper.open("PUT","http://localhost:8080/admin/updateVendor");
        helper.setRequestHeader("Content-Type", "application/json")
        helper.send(JSON.stringify(vendor));  
    }


    const OnTextChange = (args) => {
        var copyOfVendor =
            { ...vendor };
        copyOfVendor[args.target.name] =
            args.target.value;
        setVendor(copyOfVendor);
    }



    return (

        <div>
             <section
    className="grid grid-cols-1 md:grid-cols-2 gap-2 w-full "
    id="aboutUs"
    >
      <div className="py-2 flex-1 flex flex-col items-start justify-center gap-6">
        <div className="flex items-center gap-2 justify-center bg-orange-100 px-4 py-1 rounded-full">
          <p className="text-[1.5rem] lg:text-[1.5rem] text-orange-500 font-semibold">
            <h1 >Admin Dashboard !</h1>
          </p>
         
        </div>
        </div>
        </section>
            <center>
            <div  className="w-full max-w-sm p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-6 md:p-8 dark:bg-gray-200 dark:border-gray-700 drop-shadow-lg" >
                

               
                <form>
                    <div className="mb-6">
                        <label
                            htmlFor="email"
                            className="block mb-2 text-sm font-medium text-gray-900 dark:text-black"
                        >
                            Vendor Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            name='vendorEmail'
                            value={vendor.vendorEmail}
                            onChange={OnTextChange}
                            className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light"
                            placeholder="name@flowbite.com"
                            required="required"
                        />
                    </div>
                    <div className="mb-6">
                        <label
                            htmlFor="password"
                            className="block mb-2 text-sm font-medium text-gray-900 dark:text-black"
                        >
                            Vendor Password
                        </label>
                        <input
                            type="password"
                            id="password"
                            name='vendorPassword'
                            value={vendor.vendorPassword}
                            onChange={OnTextChange}
                            className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light"
                            required=""
                        />
                    </div>
                    <div className="mb-6">
                        <label
                            htmlFor="Name"
                            className="block mb-2 text-sm font-medium text-gray-900 dark:text-black"
                        >
                            Vendor Name
                        </label>
                        <input
                            type="text"
                            id="name"
                            name='vendorName'
                            value={vendor.vendorName}
                            onChange={OnTextChange}
                            className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light"
                            required=""
                        />
                    </div>

                    <div className="mb-6">
                        <label
                            htmlFor="Address"
                            className="block mb-2 text-sm font-medium text-gray-900 dark:text-black"
                        >
                            Vendor Address
                        </label>
                        <input
                            type="text"
                            id="name"
                            name='vendorAddress'
                            value={vendor.vendorAddress}
                            onChange={OnTextChange}
                            className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light"
                            required=""
                        />
                    </div>
                    {/* <div className="flex items-start mb-6">
    <div className="flex items-center h-5">
      <input
        id="terms"
        type="checkbox"
        defaultValue=""
        className="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-blue-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800"
        required=""
      />
    </div> */}
                    {/* <label
      htmlFor="terms"
      className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300"
    >
      I agree with the{" "}
      <a href="#" className="text-blue-600 hover:underline dark:text-blue-500">
        terms and conditions
      </a>
    </label>
  </div> */}
                    <button
                        
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        onClick={addVendor}
                    >
                        Add Vendor
                    </button>
                </form>
            </div>
            </center>
          
            <br></br>
            <br></br>
            <div className="relative overflow-x-auto rounded-lg">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400 align-middle shadow-lg " >
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-lg">
                                Vendor Id
                            </th>
                            <th scope="col" className="px-6 py-3 text-lg">
                                Vendor Name
                            </th>
                            <th scope="col" className="px-6 py-3 text-lg">
                                Vendor Email
                            </th>
                            <th scope="col" className="px-6 py-3 text-lg">
                                Vendor Address
                            </th>
                            <th scope="col" className="px-6 py-3 text-lg">
                                Delete
                            </th>
                            <th scope="col" className="px-6 py-3 text-lg">
                                Edit
                            </th>
                            <th scope="col" className="px-6 py-3 text-lg">
                                Update
                            </th>


                        </tr>
                    </thead>
                    <tbody>
                        {
                            vendors.map((vendor) => {
                                return (
                                    <tr key='eachRow' className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">

                                        <td className="px-6 py-4 text-orange-500 font-semibold">
                                            {vendor.id}
                                        </td>

                                        <td className="px-6 py-4 text-orange-500 font-semibold">
                                            {vendor.vendorName}
                                        </td>
                                        <td className="px-6 py-4  text-orange-500 font-semibold">
                                            {vendor.vendorEmail}
                                        </td>
                                        <td className="px-6 py-4  text-orange-500 font-semibold">
                                            {vendor.vendorAddress}
                                        </td >
                                        <td className="px-6 py-4 font-semibold">
                                            <button class="bg-blue-400 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full"  onClick={()=>{
                            deleteVendor(vendor.id)
                                 }}>
                                                Delete
                                            </button>
                                        </td>
                                        <td className="px-6 py-4 font-semibold">
                                            <button class="bg-blue-400 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full"  onClick={()=>{
                            editVendor(vendor.id)
                                 }}>
                                                Edit
                                            </button>
                                        </td>
                                        <td className="px-6 py-4 font-semibold">
                                            <button class="bg-blue-400 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full"  onClick={updateVendor}
                            
                                 >
                                                Update
                                            </button>
                                        </td>
                                    </tr>
                                )

                            })

                        }

                    </tbody>
                </table>
            </div>
        </div>




    )
}

export default Vendors

