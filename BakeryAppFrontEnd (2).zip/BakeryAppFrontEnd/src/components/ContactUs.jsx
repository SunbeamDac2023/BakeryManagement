import React from 'react'
import HeroBg from "../img/heroBg.png";
import Cheff from "../img/cheff.png";


const ContactUs = () => {
  return (
    <div>
         <section
    className="grid grid-cols-1 md:grid-cols-2 gap-2 w-full "
    id="ContactUs"
    >
      <div className="py-2 flex-1 flex flex-col items-start justify-center gap-6">
        <div className="flex items-center gap-2 justify-center bg-orange-100 px-4 py-1 rounded-full">
          <p className="text-[1.5rem] lg:text-[1.5rem] text-orange-500 font-semibold">
            <h1 >Contact Us !</h1>
          </p>
         
        </div>

        <p className="text-[2.5rem] lg:text-[4.5rem] font-bold tracking-wide text-headingColor">
          We are listening
          <span className="text-orange-800 text-[3rem] lg:text-[5rem]">
             you !
          </span>
        </p>

        <p className="text-[1.5rem] lg:text-[1.6rem] text-textColor text-center md:text-justify md:w-[80%]">
        Have a question, special request, or just want to share your love for our treats? We're all ears! Get in touch with us through the following contacts, and we'll be delighted to connect.
        <br></br>
        <br></br>
         
        <h1 className='text-orange-500 font-semibold'>Hinjewadi,Pune</h1>
        <br></br>

        contact : 7894561230
        <br></br> 
        <br></br>
        Email : SixteenthCraveBetterH@gmil.com
        <br></br>
        <br></br>
        <hr></hr>
        <br></br>
        <br></br>
        
        <h1 className='text-orange-500 font-semibold'> Baner,Pune</h1>
        
        <br></br>

        contact : 7894561230

         <br></br>
         <br></br>
         Email : SixteenthCraveBetterB@gmil.com

         <br></br>
         <br></br>


Thank you for being a part of our journey at Sixteenth-CraveBetter. We look forward to filling your days with sweetness and becoming your go-to destination for all things baked with love.

        </p>
       
        
      </div>
      <div className="py-2 flex-1 flex items-center relative">
        <img
          src={HeroBg}
          className=" ml-auto h-420 w-full lg:w-880 lg:h-650"
          alt="hero-bg"
        />
       
       <div className="w-full h-full absolute top-0 left-0 flex items-center justify-center lg:px-40 py-4 gap-4 flex-wrap">
       <img
          src={Cheff}
          className=" ml-auto h-225 w-full lg:w-350 lg:h-510 drop-shadow-md backdrop-blur-md"
          alt="cheff-png"
        />
       </div>
        </div>
        </section>
    </div>
  )
}

export default ContactUs