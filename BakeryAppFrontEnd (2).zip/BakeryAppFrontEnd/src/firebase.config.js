import { getApp, getApps, initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";


const firebaseConfig = {
    apiKey: "AIzaSyAsUx-JJ94iOFb6RLOWifFGZorzT0cHrNw",
    authDomain: "bakeryapp-4bd9b.firebaseapp.com",
    databaseURL: "https://bakeryapp-4bd9b-default-rtdb.firebaseio.com",
    projectId: "bakeryapp-4bd9b",
    storageBucket: "bakeryapp-4bd9b.appspot.com",
    messagingSenderId: "1005270010580",
    appId: "1:1005270010580:web:8851465d76c4dcd9f5c941"
  };


const app = getApps.length > 0 ? getApp() : initializeApp(firebaseConfig);

const firestore = getFirestore(app);
const storage = getStorage(app);

export { app, firestore, storage };