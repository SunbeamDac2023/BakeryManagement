import I1 from "../img/i1.png";
import F1 from "../img/f1.png";
import CK2 from "../img/ck2.png";
import DS2 from "../img/ds2.png";

export const heroData = [
  {
    id: 1,
    name: "Icecream",
    decp: "Chocolate & vanilla",
    price: "5.25",
    imageSrc: I1,
  },
  {
    id: 2,
    name: "Strawberries",
    decp: "Fresh Strawberries",
    price: "10.25",
    imageSrc: F1,
  },
  {
    id: 3,
    name: "Chocolate Cake",
    decp: "Belgium Chocolate",
    price: "8.25",
    imageSrc: CK2,
  },
  {
    id: 4,
    name: "Vanilla Dessert",
    decp: "Vanilla ",
    price: "5.25",
    imageSrc: DS2,
  },

  
];


export const categories = [
  {
    id: 1,
    name: "Brownies",
    urlParamName: "brownies",
  },
  {
    id: 2,
    name: "Cakes",
    urlParamName: "cakes",
  },
  {
    id: 3,
    name: "Desserts",
    urlParamName: "desserts",
  },
  {
    id: 4,
    name: "Tea cakes",
    urlParamName: "teaCakes",
  },
  {
    id: 5,
    name: "Fruits",
    urlParamName: "fruits",
  },
  {
    id: 6,
    name: "Icecreams",
    urlParamName: "icecreams",
  },

  {
    id: 7,
    name: "Soft Drinks",
    urlParamName: "drinks",
  },
];
